

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TileActor.generated.h"

UCLASS()
class MATCH3LINE_API ATileActor : public AActor
{
	GENERATED_BODY()
};
