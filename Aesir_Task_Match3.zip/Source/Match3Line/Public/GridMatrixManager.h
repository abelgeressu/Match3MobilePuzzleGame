

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Misc/App.h"
#include "GridMatrixManager.generated.h"

#pragma region Enums

UENUM(BlueprintType)
enum class E_TYPE_OF_CUBE : uint8
{
	COLOR1				UMETA(DisplayName = "Color1"),
	COLOR2				UMETA(DisplayName = "Color2"),
	COLOR3				UMETA(DisplayName = "Color3"),
	COLOR4				UMETA(DisplayName = "Color4"),
	COLOR5				UMETA(DisplayName = "Color5"),
	SPECIALCOLOR		UMETA(DisplayName = "SpecialColor")
};

UENUM(BlueprintType)
enum class E_TYPE_OF_NOTIFY : uint8
{
	SELECT_CUBE_SFX		UMETA(DisplayName = "Select"),
	UNSELECT_CUBE_SFX	UMETA(DisplayName = "UnSelect"),
	ON_MATCH_SFX		UMETA(DisplayName = "OnMatch"),
	ON_FAILED_MATCH_SFX UMETA(DisplayName = "FailMatch"),
	
	ON_SPAWN_CUBE_VFX	UMETA(DisplayName = "SpawnCube"),
	ON_KILL_CUBE_VFX	UMETA(DisplayName = "KillCube")
};

#pragma endregion;

class AModelViewManager;
class AMyGameState;
class AMyPlayerState;
class ATileActor;
class AMyUserController;

UCLASS()
class MATCH3LINE_API AGridMatrixManager : public AActor
{
	GENERATED_BODY()
	
public:	

	AGridMatrixManager();
	
	void PlayerStartSelectingTiles(AActor* HitObject);
	void PlayerStopSelectingTiles();
	void RefreshTileColors();

private:

	AMyUserController*	MyUserController;
	AModelViewManager*	ModelView;
	AMyGameState*		MyGameState;
	AMyPlayerState*		MyPlayerState;

	TMap<ATileActor*, E_TYPE_OF_CUBE> AllCubesAndTypes;

	UPROPERTY(EditDefaultsOnly)
	TArray<UMaterialInterface*> AllMaterials;
	TArray<ATileActor*>			SelectedTiles;

	ATileActor* GridMatrix [10][7];

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class ATileActor> MyCubeObject;

	FTimerHandle ReOrderTimerHandle;
	FTimerHandle ReFillTimerHandle;
	FTimerHandle CubesFeedBackTimerHandle;

	const uint8_t gridWidth			= 10;
	const uint8_t gridHeight		= 7;
	const uint8_t minCubesToMatch	= 3;

	uint8_t delayWidthCounter		= 0;
	uint8_t delayHeightCounter		= 0;
	uint8_t delayIterations			= 0;
	uint8_t reOrderTilesRepeating	= 0;
	
	const float distanceBetweenTiles	= 50.0f;

	bool bOnFixingGrid = false;


	
	virtual void BeginPlay() override;

	
	void SpawnAllTilesGridMatrix();
	void SpawnTileActor(const FVector& cubePosition, const int32& i, const int32& j);
	void OnDestroyCube(ATileActor* ThisTile);
	void ReOrderAllTiles();
	void ReFillEmptySpaces();
	void SelectedTilesFeedBack();
	
	
	UFUNCTION()
	void ReOrderAllTilesWithDelay();
	
	UFUNCTION()
	void ReFillGridWithDelay();

	
	TArray<uint8_t> ReturnMeTileIndex(ATileActor* ThisCube);
};
