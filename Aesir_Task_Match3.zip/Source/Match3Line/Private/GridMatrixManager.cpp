

#include "GridMatrixManager.h"
#include "Kismet/GameplayStatics.h"
#include "MyGameState.h"
#include "TileActor.h"
#include "MyUserController.h"
#include "MyPlayerState.h"
#include "ModelViewManager.h"

AGridMatrixManager::AGridMatrixManager()
{
	PrimaryActorTick.bCanEverTick = false;
}

void AGridMatrixManager::BeginPlay()
{
	Super::BeginPlay();
	
	ModelView			= Cast<AModelViewManager>	(UGameplayStatics::GetActorOfClass(GetWorld(), AModelViewManager::StaticClass()));
	MyPlayerState		= Cast<AMyPlayerState>		(GetWorld()->GetGameState()->PlayerArray[0]);
	MyGameState			= Cast<AMyGameState>		(GetWorld()->GetGameState());
	MyUserController	= Cast<AMyUserController>	(GetWorld()->GetFirstPlayerController());

	SpawnAllTilesGridMatrix();

	GetWorldTimerManager().SetTimer(CubesFeedBackTimerHandle, this,
	&AGridMatrixManager::SelectedTilesFeedBack, 0.1f, true, 0.0f);
}

void AGridMatrixManager::SpawnAllTilesGridMatrix()
{
	//Makes the 2D Matrix and ask to spawn a Tile.
	float zBase = 0.0f;
	float yBase = 0.0f;

	const float TileHorizontalOffset = distanceBetweenTiles * sqrt(3) / 2;
	const float TileVerticalOffset = distanceBetweenTiles * 3 / 2;

	for (int32 i = 0; i < gridWidth; i++)
	{
		for (int32 j = 0; j < gridHeight; j++)
		{
			const float yPos = (i % 2) * TileHorizontalOffset + (j * 2 * TileHorizontalOffset);
			const float zPos = i * TileVerticalOffset;
			SpawnTileActor(GetActorLocation() + FVector(0, yBase-zPos, zBase + yPos), i,	j);
		}
		
	}
}

void AGridMatrixManager::SpawnTileActor(const FVector& cubePosition, const int32& i, const int32& j)
{
	//Creates a Tile  with a value and a color type, and save it into a 2D Matrix.
	int32 randomValue = FMath::RandRange(0, AllMaterials.Num() - 1);
	
	FActorSpawnParameters parameters;

	ATileActor* ThisTile =	GetWorld()->SpawnActor<ATileActor>(MyCubeObject, cubePosition,
							GetActorRotation(), parameters);
		
	//Saves Tile in HexagonalMatrix.
	GridMatrix[i][j] = static_cast<ATileActor*>(ThisTile);
	
	//Changes Tile material.
	ThisTile->FindComponentByClass<UStaticMeshComponent>()->SetMaterial(0, AllMaterials[randomValue]);
	
	AllCubesAndTypes.Emplace(ThisTile, static_cast<E_TYPE_OF_CUBE>(randomValue));
}

void AGridMatrixManager::PlayerStartSelectingTiles(AActor* HitObject)
{
	//If we are re-ordering or re-filling the grid, it will ignore de Player Input.
	if(bOnFixingGrid) return;

	if (ATileActor* TempCube = static_cast<ATileActor*>(HitObject))
	{
		//If it is our first Tile, we add it.
		if (SelectedTiles.Num() == 0)
		{
			SelectedTiles.Emplace(TempCube);
			ModelView->DrawLineMatch(TempCube->GetActorLocation());
			ModelView->PlaySoundSFX(E_TYPE_OF_NOTIFY::SELECT_CUBE_SFX);
		}

		else
		{
			//I save the X and Y position of this Current Tile in the 2D Matrix.
			TArray<uint8_t> XY_Indexs			= ReturnMeTileIndex(TempCube);
			
			TArray<uint8_t> XY_OLDTILE_Indexs	= ReturnMeTileIndex(SelectedTiles[SelectedTiles.Num() - 1]);

			//If I didn't have the cube I'm Selected, it means is a new one.
			if (!SelectedTiles.Contains(TempCube))
			{
				//It checks adjacents cubes in 2D Matrix. It checks one To Right, one to Left, one Up and one Down.
				if (XY_Indexs[0] == XY_OLDTILE_Indexs[0] - 1 && XY_Indexs[1] == XY_OLDTILE_Indexs[1] ||
					XY_Indexs[0] == XY_OLDTILE_Indexs[0] + 1 && XY_Indexs[1] == XY_OLDTILE_Indexs[1] ||
					XY_Indexs[0] == XY_OLDTILE_Indexs[0] + 1 && XY_Indexs[1] == XY_OLDTILE_Indexs[1] - 1 ||
					XY_Indexs[0] == XY_OLDTILE_Indexs[0] + 1 && XY_Indexs[1] == XY_OLDTILE_Indexs[1] + 1 ||
					XY_Indexs[1] == XY_OLDTILE_Indexs[1] - 1 && XY_Indexs[0] == XY_OLDTILE_Indexs[0] ||
					XY_Indexs[1] == XY_OLDTILE_Indexs[1] + 1 && XY_Indexs[0] == XY_OLDTILE_Indexs[0]||
					XY_Indexs[1] == XY_OLDTILE_Indexs[1] + 1 && XY_Indexs[0] == XY_OLDTILE_Indexs[0]-1 ||
				    XY_Indexs[1] == XY_OLDTILE_Indexs[1] + 1 && XY_Indexs[0] == XY_OLDTILE_Indexs[0]+1 )
				{
					//All right, we don't have add this tile before and is a adjacent to us. Now, we check if->
					
					if (AllCubesAndTypes[TempCube] == AllCubesAndTypes[SelectedTiles[SelectedTiles.Num() - 1]]	 ||
						AllCubesAndTypes[SelectedTiles[SelectedTiles.Num() - 1]] == E_TYPE_OF_CUBE::SPECIALCOLOR ||
						AllCubesAndTypes[TempCube] == E_TYPE_OF_CUBE::SPECIALCOLOR)
					{
						SelectedTiles.Emplace(TempCube);
						ModelView->PlaySoundSFX(E_TYPE_OF_NOTIFY::SELECT_CUBE_SFX);
						ModelView->DrawLineMatch(TempCube->GetActorLocation());
					}
				}
			}

			//If we already have the tile the player is selecting...
			else
			{
				
				if (SelectedTiles.Num() > 1)
				{
					if (TempCube == SelectedTiles[SelectedTiles.Num() - 2])
					{
						SelectedTiles[SelectedTiles.Num() - 1]->SetActorRotation(FRotator(0, 0, 0));
						
						SelectedTiles.RemoveAt(SelectedTiles.Num() - 1);
					
						ModelView->PlaySoundSFX(E_TYPE_OF_NOTIFY::UNSELECT_CUBE_SFX);
						
						ModelView->RemoveLastPointInDrawLine();
					}
				}
			}
		}
	}
}

void AGridMatrixManager::PlayerStopSelectingTiles()
{
	for (auto& Elem : SelectedTiles)
		Elem->SetActorRotation(FRotator(0,0,0));
		
	if (SelectedTiles.Num() >= minCubesToMatch)
	{		
		for (auto& Elem : SelectedTiles)
		{
			OnDestroyCube(Elem);
		}

		
		ModelView->PlaySoundSFX(E_TYPE_OF_NOTIFY::ON_MATCH_SFX);
		//Subtrack one movement.
		MyGameState->SubtractAPlayerMove();
		
		MyPlayerState->AddPlayerScore(SelectedTiles.Num());

		
		ReOrderAllTiles();
	}
	
	else
		ModelView->PlaySoundSFX(E_TYPE_OF_NOTIFY::ON_FAILED_MATCH_SFX);

	
	SelectedTiles.Empty();
	
	ModelView->StopDrawing();
}

void AGridMatrixManager::SelectedTilesFeedBack()
{
	if (SelectedTiles.Num() > 0)
	{
		for (auto& Elem : SelectedTiles)
		{
			int32 randomvalue = FMath::RandRange(-5, 5);
			Elem->SetActorRotation(FRotator(0, 0, randomvalue));
		}
	}
}

void AGridMatrixManager::RefreshTileColors()
{
	if (bOnFixingGrid || SelectedTiles.Num() > 0) return;
		
	AllCubesAndTypes.Empty();

	//Iterates through all 2D Matrix to change tiles values.
	for (int32 i = 0; i < gridWidth; i++)
	{
		for (int32 j = 0; j < gridHeight; j++)
		{
			int32 randomValue = FMath::RandRange(0, AllMaterials.Num() - 1);

			ATileActor* ThisCube = GridMatrix[i][j];
			ThisCube->FindComponentByClass<UStaticMeshComponent>()->SetMaterial(0, AllMaterials[randomValue]);

			AllCubesAndTypes.Emplace(ThisCube, (E_TYPE_OF_CUBE)randomValue);
		}
	}
}

void AGridMatrixManager::OnDestroyCube(ATileActor* ThisTile)
{
	
	ThisTile->SetActorHiddenInGame(true);
	ThisTile->SetActorEnableCollision(false);
	
	ModelView->SpawnVFX(ThisTile->GetActorLocation(), E_TYPE_OF_NOTIFY::ON_KILL_CUBE_VFX);
}

void AGridMatrixManager::ReOrderAllTiles()
{
	
	bOnFixingGrid = true;
	delayHeightCounter = 1;
	
	float delayTime = 0.0005f;

	MyUserController->UpdateFixingGridStart(bOnFixingGrid);
	
	GetWorldTimerManager().SetTimer(ReOrderTimerHandle, this, &AGridMatrixManager::ReOrderAllTilesWithDelay, delayTime, true, 0);	
}

void AGridMatrixManager::ReOrderAllTilesWithDelay()
{	
	
	if (reOrderTilesRepeating == gridHeight)
	{
		GetWorldTimerManager().ClearTimer(ReOrderTimerHandle);
	
		delayWidthCounter = 0;
		delayHeightCounter = 0;
		delayIterations = 0;
		reOrderTilesRepeating = 0;

		//Once it's reorder the whole grid, now fills the empty spaces.
		ReFillEmptySpaces();
	}
	
	else
	{
		//Subtracts gridWidth once because we don't want to check the tile on the floor.
		if (delayIterations == (gridWidth * gridHeight) - gridWidth)
		{
			//If it's iterate the whole grid, adds one to "reOrder tile Repeating" (to know when to stop) 
			//And then, reset his value to start check everything again.
			reOrderTilesRepeating++;
			delayIterations = 0;
		}
				
		else
		{
			//if we are on the top of the gridHeight
			//we reset this value and check one more in X.
			if (delayHeightCounter == gridHeight)
			{
				delayHeightCounter = 1;
				
				delayWidthCounter = delayWidthCounter == gridWidth - 1 ? 0 : delayWidthCounter = delayWidthCounter + 1;
			}

			//If this tile is not hidden and the one below it is, we can make this tile go down.
			if (!GridMatrix[delayWidthCounter][delayHeightCounter]->IsHidden() &&
				 GridMatrix[delayWidthCounter][delayHeightCounter - 1]->IsHidden())
			{
				//We Swap tiles
				ATileActor* DestroyedCube	= GridMatrix[delayWidthCounter][delayHeightCounter - 1];
				ATileActor* ThisCube		= GridMatrix[delayWidthCounter][delayHeightCounter];

				FVector destroyedCubePosition	= DestroyedCube->GetActorLocation();
				FVector ThisCubePosition		= ThisCube->GetActorLocation();

				GridMatrix[delayWidthCounter][delayHeightCounter]		->SetActorLocation(destroyedCubePosition);
				GridMatrix[delayWidthCounter][delayHeightCounter - 1]	->SetActorLocation(ThisCubePosition);

				GridMatrix[delayWidthCounter][delayHeightCounter]		= DestroyedCube;
				GridMatrix[delayWidthCounter][delayHeightCounter - 1]	= ThisCube;
			}
			
			//Once it went through this column, he moves to the next.
			delayHeightCounter++;
			delayIterations++;
		}
	}
}

void AGridMatrixManager::ReFillEmptySpaces()
{	
	float delayTime = 0.005f;

	//This function activate hidden cubes with a little bit of delay feedback.
	GetWorldTimerManager().SetTimer(ReFillTimerHandle, this, &AGridMatrixManager::ReFillGridWithDelay, delayTime, true, 0);
}

void AGridMatrixManager::ReFillGridWithDelay()
{
	//If delayIterations >= all cubes amount it means that we have iterate the whole 2D Matrix.
	if (delayIterations >= gridWidth * gridHeight)
	{
		GetWorldTimerManager().ClearTimer(ReFillTimerHandle);
		
		delayWidthCounter = 0;
		delayHeightCounter = 0;
		delayIterations = 0;
		
		//Some feedback UI.
		bOnFixingGrid = false;
		MyUserController->UpdateFixingGridStart(bOnFixingGrid);
	}
	
	else
	{
		delayWidthCounter  = delayWidthCounter  == gridWidth  ? 0 : delayWidthCounter;
		delayHeightCounter = delayHeightCounter	== gridHeight ? 0 : delayHeightCounter;

		//If this tile is hidden...
		if (GridMatrix[delayWidthCounter][delayHeightCounter]->IsHidden())
		{
			//Spawns a particle
			ModelView->SpawnVFX(GridMatrix[delayWidthCounter][delayHeightCounter]->GetActorLocation(), E_TYPE_OF_NOTIFY::ON_SPAWN_CUBE_VFX);

			//Activates this tile's plane and physics
			GridMatrix[delayWidthCounter][delayHeightCounter]->SetActorHiddenInGame(false);
			GridMatrix[delayWidthCounter][delayHeightCounter]->SetActorEnableCollision(true);

			//it assigns it a random color and save this tile.
			int32 randomValue	= FMath::RandRange(0, AllMaterials.Num() - 1);
			auto ThisCube		= GridMatrix[delayWidthCounter][delayHeightCounter];
			
			ThisCube->FindComponentByClass<UStaticMeshComponent>()->SetMaterial(0, AllMaterials[randomValue]);

			AllCubesAndTypes.Emplace(ThisCube, (E_TYPE_OF_CUBE)randomValue);
		}
	}
	
	delayHeightCounter++;
	delayWidthCounter++;
	delayIterations++;
}

TArray<uint8_t> AGridMatrixManager::ReturnMeTileIndex(ATileActor* ThisCube)
{
	//Iterates the whole 2D Matrix and If a cubes match 
	//returns an array with two values = X and Y position.
	for (int i = 0; i < gridWidth; i++)
	{
		for (int j = 0; j < gridHeight; j++)
		{
			if (GridMatrix[i][j] == ThisCube)
			{
				TArray<uint8_t> TempArray;
				TempArray.Emplace(i);
				TempArray.Emplace(j);
				return TempArray;
			}
		}
	}
	return TArray<uint8_t>();
}